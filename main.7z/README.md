# auto_work
通过url获取图片并显示
#python 3.9
使用
pip install --no-index --find-links=./packs -r requirements.txt 
命令离线下载所需要的包