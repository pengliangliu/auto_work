# --------------------------------------------------------------------------
# Source file provided under Apache License, Version 2.0, January 2004,
# http://www.apache.org/licenses/
# (c) Copyright IBM Corp. 2015, 2022
# --------------------------------------------------------------------------

# gendoc: ignore
# This file is generated !
# See script tools/gen_version.py
docplex_version_major = 2
docplex_version_minor = 25
docplex_version_micro = 236
docplex_version_string = '2.25.236'

latest_cplex_major = 22
latest_cplex_minor = 1
